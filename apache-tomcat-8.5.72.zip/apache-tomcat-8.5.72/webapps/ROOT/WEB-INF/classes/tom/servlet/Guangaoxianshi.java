package tom.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tom.bean.Login;
import tom.bean.Guanggao;

public class Guangaoxianshi extends HttpServlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		// ��������
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
					.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.init(config);
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		Login login = (Login) session.getAttribute("login");// ��ȡ�û���¼ʱ��JavaBean
		boolean ok = true;
		if (login == null) {
			ok = false;
			response.sendRedirect("login.jsp");
		}
		if (ok == true) {
                                                String logname = login.getLogname();// ��õ�¼��
                                                continueDoGet(request, response,logname);
		}
}
	private void continueDoGet(HttpServletRequest request,
			HttpServletResponse response, String logname) throws ServletException, IOException {
		Guanggao showResult = new Guanggao();// ��ȡGuanggao��JavaBean
		request.setAttribute("showResult", showResult);
		StringBuffer str=new StringBuffer();
		// ��ȡ����
		try {
			String uri = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=ComeHere";
			String user = "sa";
			String password = "Fury@0218";
			Connection con = DriverManager.getConnection(uri, user, password);
			// ����Statement����
			Statement st = con.createStatement();
			//����sql��䣬���ݻ�Ա����ѯ��Ա��Ϣ
			String sql="select * from shuju where guangaoname='"+logname+"'";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				str.append("<tr>");
				String s="<img src=Project2/image2/"+rs.getString(2)+"/"+rs.getString(2)+" "+"width=800 height=200/>";
				str.append("<td>"+s+"</td>");
				str.append("</tr>");
			}
		}catch(Exception e){
				response.setContentType("text/html;charset=GB2312");
				PrintWriter out=response.getWriter();
				out.println("<html><body>");
				out.println("��ѯ�������");
				out.println("</body></html>");
		}
		showResult.setResult(new String(str));
		System.out.println(showResult.getResult());
		RequestDispatcher dispatcher=request.getRequestDispatcher("xx.jsp");
		dispatcher.forward(request, response);

	}
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
