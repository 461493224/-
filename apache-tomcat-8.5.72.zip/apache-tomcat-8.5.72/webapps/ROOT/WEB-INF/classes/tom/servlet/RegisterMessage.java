package tom.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tom.bean.Register;

public class RegisterMessage extends HttpServlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		// ��������
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
					.newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.init(config);
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// ��ȡ�������ݹ����Ĳ���
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("logname");
		String pwd = request.getParameter("password");
		String pwd1 = request.getParameter("password1");
		String s = request.getParameter("sex");
		String a = request.getParameter("age");
		String e = request.getParameter("email");
		String p = request.getParameter("phone");
		String m = request.getParameter("message");
                                int a2 = 0;
                                int n=0;
		try {
			a2 = Integer.parseInt(a);
                                                n=e.indexOf("@");	
		} catch (NumberFormatException e1) {
			e1.printStackTrace();
		}
		if (name == null || name.equals("")) {
			showMessage("��Ա���Ʋ���Ϊ��", response);
		} else if (pwd == null || pwd.equals("")) {
			showMessage("�������벻��Ϊ��", response);
		} else if (!pwd.equals(pwd1)) {
			showMessage("�����������벻һ��", response);
		} else if (a2<=0 || a2>=120){
                                                showMessage("��������ȷ�����䷶Χ",response);
		} else if (e==null || e.equals("")){
                                                showMessage("Email����Ϊ��",response);
		} else if (n==-1){
                                                showMessage("��������ȷ��Email��ʽ",response);
		} else {
			// ��ȡ����
			try {
				String uri = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=ComeHere";
				String user = "sa";
				String password = "Fury@0218";
				Connection con = DriverManager.getConnection(uri, user,
						password);
				// ����Statement�������ڷ��ͺ�ִ��SQL���
				Statement st = con.createStatement();
				int age=0;
				if(!(a==null || a.equals(""))){
					age=Integer.parseInt(a);
				}
				
				// ����sql���
				String sql = "insert into member(logname,password,sex,age,phone,email,message) values ('"+name+"','"+pwd+"','"+s+"','"+age+"','"+p+"','"+e+"','"+m+"')";
				// ִ��sql��䣬��������
				int i = st.executeUpdate(sql);
				if(i!=0){
					Register register=new Register();//��ȡRegister����
					//������Ӧ������
					register.setLogname(name);
					register.setPassword(pwd1);
					register.setSex(s);
					register.setAge(age);
					register.setPhone(p);
					register.setEmail(e);
					register.setMessage(m);
					/*��JavaBeanд��request������*/
					request.setAttribute("register", register);
					//ע��ɹ�����ת�ض���
					RequestDispatcher dispatcher=request.getRequestDispatcher("registerMessage.jsp");
					dispatcher.forward(request, response);
				}else{
					showMessage("�����쳣�����Ժ�����",response);
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void showMessage(String message, HttpServletResponse response)
			throws IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charSet=GB2312");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println(message + ",");
		out.println("<a href='register.jsp'>����ע��</a>");
		out.println("</body></html>");
	}
}
