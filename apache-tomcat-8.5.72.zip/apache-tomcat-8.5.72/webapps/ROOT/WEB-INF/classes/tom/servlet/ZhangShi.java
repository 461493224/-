package tom.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tom.bean.Login;


public class ZhangShi extends HttpServlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
					.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.init(config);
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		Login login = (Login) session.getAttribute("login");
		boolean ok = true;
		if (login == null) {
			ok = false;
			response.sendRedirect("login.jsp");
		}
		if (ok == true) {
                                                String NB = request.getParameter("Number");
                                                String mx = request.getParameter("MX");
                                                String url1 = request.getParameter("ur");
                                                String logname = login.getLogname();
                                                continueDoGet(request, response,logname,NB,mx,url1);
		}
}
	private void continueDoGet(HttpServletRequest request,
			HttpServletResponse response, String logname,String NB,String mx,String url1) throws ServletException, IOException {
		try {
			String uri = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=ComeHere";
			String user = "sa";
			String password = "Fury@0218";
			Connection con = DriverManager.getConnection(uri, user, password);

			Statement st = con.createStatement();

                                                String sql1="select MAX(number) from shuju where guangaoname='"+logname+"'";
                                                ResultSet mz=st.executeQuery(sql1);
                                                if(mz.next()){
                                                int ccc = mz.getInt(1);
                                                int NB1=Integer.parseInt(NB);
                                                if (NB1>ccc){
                                                int qqq=0;
                                                if (qqq!=0){
                                                String sql="select guangao from shuju where guangaoname='"+logname+"' and Number='"+NB+"'";
			ResultSet rs=st.executeQuery(sql);
                                                url1=rs.getString(1);
                                                if (url1!="NILL") {
                                                                
				request.setCharacterEncoding("utf-8");
                                                                response.setCharacterEncoding("utf-8");
                                                                request.setAttribut("MX","ccc");
                                                                request.setAttribut("url1","url1");
                                                                request.getRequestDispatcher("bottom.jsp");
                                                
			}
                                                }
		}
}
                                                }catch(Exception e){
				response.setContentType("text/html;charset=GB2312");
				PrintWriter out=response.getWriter();
				out.println("<html><body>");
				out.println("??????????");
				out.println("</body></html>");

		}

	}
}

